import * as Dialog from "@radix-ui/react-dialog";

interface MaintenanceModalProps {
  open: boolean;
}

export function MaintenanceModal({ open }: MaintenanceModalProps) {
  return (
    <Dialog.Root open={open}>
      <Dialog.Overlay className="fixed inset-0 bg-black/50" />
      <Dialog.Content className="fixed top-1/2 left-1/2 w-96 -translate-x-1/2 -translate-y-1/2 rounded-lg bg-white p-6 shadow-lg">
        <Dialog.Title className="text-xl font-bold">🚧 Scheduled Maintenance</Dialog.Title>
        <Dialog.Description className="mt-2">
      <div style={styles.container}>
        <p style={styles.message}>App is under a scheduled outage
            from September 19 6:00 PM to 10:00 PM IST. We will notify once solution
            is functional..</p>
       
     
 
  </div>        </Dialog.Description>
      </Dialog.Content>
    </Dialog.Root>
  );
}

const styles = {
  page: {
  display: 'flex',
  flexDirection: 'column',
  minHeight: '10vh',
  backgroundColor: '#f2f2f2',
  overflowX: 'hidden',
  },
 
  content: {
    flex: 1,
    // display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
 
  container: {
    padding: '2rem',
      textAlign: 'center',
      backgroundColor: '#D3D3D3',
      borderRadius: '8px',
      margin: '2rem',
      // width: '100%',
  },
 
  heading: {
    fontSize: '2rem',
    marginBottom: '1rem',
    color: '#333',
  },
  message: {
    fontSize: '1.1rem',
    marginBottom: '1.5rem',
    color: '#666',
  },
  button: {
    padding: '0.6rem 1.5rem',
    fontSize: '1rem',
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modal: {
    backgroundColor: '#fff',
    padding: '2rem',
    borderRadius: '10px',
    width: '90%',
    maxWidth: '500px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
  },
  modalHeading: {
    fontSize: '1.5rem',
    marginBottom: '1rem',
    color: '#333',
  },
  textarea: {
    width: '100%',
    minHeight: '100px',
    fontSize: '1rem',
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #ccc',
    resize: 'vertical',
    marginBottom: '1rem',
  },
  modalActions: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '0.8rem',
  },
  cancelBtn: {
    padding: '0.5rem 1.2rem',
    backgroundColor: '#6c757d',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  submitBtn: {
    padding: '0.5rem 1.2rem',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  // Footer styles
  footer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    padding: '1rem 2rem',
    backgroundColor: '#e0e0e0',
    color: '#555',
    fontSize: '0.9rem',
  },
 
  footerLeft: {
    flex: 1,
    textAlign: 'left',
  },
 
  footerCenter: {
    flex: 1,
    textAlign: 'center',
    fontWeight: '500',
  },
 
  footerRight: {
    flex: 1,
    textAlign: 'right',
  },
  loaderOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2000,
  },
};
 
 