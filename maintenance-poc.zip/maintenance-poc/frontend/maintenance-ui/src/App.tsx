import { useEffect, useState } from "react";
import * as signalR from "@microsoft/signalr";
import { MaintenanceModal } from "./MaintenanceModal";

export default function App() {
  const [maintenance, setMaintenance] = useState(false);
  const [connection, setConnection] = useState<signalR.HubConnection | null>(null);

  useEffect(() => {
    // Build connection
    const newConnection = new signalR.HubConnectionBuilder()
      .withUrl("http://localhost:5124/maintenanceHub") // exact hub URL
      .withAutomaticReconnect()
      .configureLogging(signalR.LogLevel.Information)
      .build();

    setConnection(newConnection);

    // Start connection
    newConnection
      .start()
      .then(() => console.log("SignalR connected"))
      .catch(err => console.error("SignalR connection error:", err));

    // Listen to maintenance events
    newConnection.on("maintenance_mode", (status: boolean) => {
      console.log("Maintenance update:", status);
      setMaintenance(status);
    });

    // Cleanup on unmount
    return () => {
      newConnection.stop().then(() => console.log("SignalR connection stopped"));
    };
  }, []);

  return (
    <>
      <h1 className="text-2xl font-bold p-4">Welcome to the App</h1>
      <MaintenanceModal open={maintenance} />
    </>
  );
}
