using Microsoft.AspNetCore.SignalR;

public class MaintenanceHub : Hub
{
    private readonly ILogger<MaintenanceHub> _logger;

    public MaintenanceHub(ILogger<MaintenanceHub> logger)
    {
        _logger = logger;
    }

    public async Task BroadcastMaintenance(bool status)
    {
        _logger.LogInformation("Broadcasting maintenance status: {Status}", status);
        await Clients.All.SendAsync("maintenance_mode", status);
    }
}
