public class MaintenanceRequest
{
    public bool Status { get; set; }
}
