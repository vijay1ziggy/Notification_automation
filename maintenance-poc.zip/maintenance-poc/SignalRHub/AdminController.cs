using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

[ApiController]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly IHubContext<MaintenanceHub> _hub;
    private readonly ILogger<AdminController> _logger;

    public AdminController(IHubContext<MaintenanceHub> hub, ILogger<AdminController> logger)
    {
        _hub = hub;
        _logger = logger;
    }

    [HttpPost("maintenance")]
    public async Task<IActionResult> TriggerMaintenance([FromBody] MaintenanceRequest  request)
    {
        _logger.LogInformation("HTTP Trigger: Broadcasting maintenance status {Status}", request.Status);

        // Call your hub method
        await _hub.Clients.All.SendAsync("maintenance_mode", request.Status);

        return Ok(new { sent = true });
    }
}
