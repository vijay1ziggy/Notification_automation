var builder = WebApplication.CreateBuilder(args);

// Add CORS policy
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy
            .WithOrigins("http://localhost:5174") // React dev server
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials();
    });
});

builder.Services.AddSignalR();
builder.Services.AddControllersWithViews();
var app = builder.Build();

// Use CORS before mapping hubs
app.UseCors();
app.MapControllers();  
app.MapHub<MaintenanceHub>("/maintenanceHub");

app.Run();
