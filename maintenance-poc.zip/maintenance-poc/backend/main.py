from fastapi import FastAPI, Body
import requests

app = FastAPI()

MAINTENANCE = False
WORKER_URL = "http://localhost:6000/notify"

@app.post("/admin/maintenance")
def toggle_maintenance(status: bool = Body(...)):
    global MAINTENANCE
    MAINTENANCE = status
    # Notify worker service
    requests.post(WORKER_URL, json={"status": status})
    return {"maintenance": MAINTENANCE}

@app.get("/status")
def get_status():
    return {"maintenance": MAINTENANCE}

#curl -X POST "http://localhost:8000/admin/maintenance" -H "Content-Type: application/json" -d "false"