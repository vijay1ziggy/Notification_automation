from fastapi import FastAPI
from pydantic import BaseModel
import requests

app = FastAPI()

SIGNALR_BROADCAST_URL = "http://localhost:5124/api/admin/maintenance"

class NotifyPayload(BaseModel):
    status: bool

@app.post("/notify")
def notify(payload: NotifyPayload):
    requests.post(SIGNALR_BROADCAST_URL, json={"status": payload.status})
    return {"sent": True}
